
int example(){
  return 29;
}

int main(){
  return example();
}
